import { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts';

export default function Dashboard() {
  const [selectedUnit, setSelectedUnit] = useState(null);
  const [activeSection, setActiveSection] = useState('automated');

  const units = [
    { id: 1, name: "الجهة 1" },
    { id: 2, name: "الجهة 2" },
    { id: 3, name: "الجهة 3" },
    { id: 4, name: "الجهة 4" },
  ];

  const satisfactionData = [
    { name: 'راضون', value: 90 },
    { name: 'غير راضين', value: 10 }
  ];

  const requestsData = [
    { name: 'منجزة', value: 150 },
    { name: 'قيد التنفيذ', value: 30 },
    { name: 'جديدة', value: 20 }
  ];

  const responseTimeData = [
    { name: 'أقل من 12 ساعة', value: 60 },
    { name: '12-24 ساعة', value: 30 },
    { name: 'أكثر من 24 ساعة', value: 10 }
  ];

  const lineChartData = [
    { month: 'يناير', satisfaction: 85, requests: 120, responseTime: 24 },
    { month: 'فبراير', satisfaction: 88, requests: 140, responseTime: 20 },
    { month: 'مارس', satisfaction: 92, requests: 160, responseTime: 16 },
    { month: 'أبريل', satisfaction: 90, requests: 180, responseTime: 12 },
    { month: 'مايو', satisfaction: 95, requests: 200, responseTime: 8 },
    { month: 'يونيو', satisfaction: 93, requests: 220, responseTime: 6 },
  ];

  const COLORS = {
    satisfaction: ['#006838', '#D4AF37'],
    requests: ['#006838', '#D4AF37', '#808080'],
    responseTime: ['#006838', '#D4AF37', '#808080']
  };

  const renderEntityContent = (entityId) => (
    <div className="space-y-6">
      {/* Navigation Tabs */}
      <div className="flex space-x-reverse space-x-4 border-b border-gray-200">
        <button
          onClick={() => setActiveSection('automated')}
          className={`px-4 py-2 -mb-px ${
            activeSection === 'automated'
              ? 'border-b-2 border-[#006838] text-[#006838] font-semibold'
              : 'text-gray-500 hover:text-[#006838]'
          }`}
        >
          الخدمات المؤتمته
        </button>
        <button
          onClick={() => setActiveSection('dashboard')}
          className={`px-4 py-2 -mb-px ${
            activeSection === 'dashboard'
              ? 'border-b-2 border-[#006838] text-[#006838] font-semibold'
              : 'text-gray-500 hover:text-[#006838]'
          }`}
        >
          لوحة مؤشرات الأداء التفاعلية
        </button>
        <button
          onClick={() => setActiveSection('reports')}
          className={`px-4 py-2 -mb-px ${
            activeSection === 'reports'
              ? 'border-b-2 border-[#006838] text-[#006838] font-semibold'
              : 'text-gray-500 hover:text-[#006838]'
          }`}
        >
          التقارير
        </button>
      </div>

      {/* Content for each section */}
      {activeSection === 'automated' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow border-2 border-[#006838] text-[#006838] hover:bg-[#006838] hover:text-white">
              <h3 className="text-lg font-semibold mb-2">طلب خدمة جديدة</h3>
              <p className="text-sm opacity-75">تقديم طلب للحصول على خدمة إلكترونية</p>
            </button>
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow border-2 border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-white">
              <h3 className="text-lg font-semibold mb-2">متابعة الطلبات</h3>
              <p className="text-sm opacity-75">عرض حالة الطلبات المقدمة</p>
            </button>
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow border-2 border-gray-500 text-gray-500 hover:bg-gray-500 hover:text-white">
              <h3 className="text-lg font-semibold mb-2">الخدمات المتاحة</h3>
              <p className="text-sm opacity-75">استعراض جميع الخدمات المتوفرة</p>
            </button>
          </div>
        </div>
      )}

      {activeSection === 'dashboard' && entityId === 2 && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Satisfaction Rate Chart */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-[#006838] mb-4 text-center">نسبة رضا المستفيدين</h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={satisfactionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      fill="#8884d8"
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {satisfactionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS.satisfaction[index % COLORS.satisfaction.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Completed Requests Chart */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-[#006838] mb-4 text-center">عدد الطلبات المنجزة</h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={requestsData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {requestsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS.requests[index % COLORS.requests.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Response Time Chart */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-[#006838] mb-4 text-center">متوسط وقت الاستجابة</h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={responseTimeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      fill="#8884d8"
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {responseTimeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS.responseTime[index % COLORS.responseTime.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-4 rounded-lg shadow-md border-r-4 border-[#006838]">
              <p className="text-sm text-gray-600">إجمالي نسبة الرضا</p>
              <p className="text-2xl font-bold text-[#006838]">90%</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-md border-r-4 border-[#D4AF37]">
              <p className="text-sm text-gray-600">إجمالي الطلبات</p>
              <p className="text-2xl font-bold text-[#D4AF37]">200</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-md border-r-4 border-gray-500">
              <p className="text-sm text-gray-600">متوسط زمن الاستجابة</p>
              <p className="text-2xl font-bold text-gray-700">12 ساعة</p>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'dashboard' && entityId === 1 && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 gap-8">
            {/* Satisfaction Rate Line Chart */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-[#006838] mb-4 text-center">نسبة رضا المستفيدين</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lineChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="satisfaction" stroke="#006838" strokeWidth={2} name="نسبة الرضا %" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Completed Requests Line Chart */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-[#006838] mb-4 text-center">عدد الطلبات المنجزة</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lineChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="requests" stroke="#D4AF37" strokeWidth={2} name="عدد الطلبات" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Response Time Line Chart */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-[#006838] mb-4 text-center">متوسط وقت الاستجابة</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lineChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="responseTime" stroke="#808080" strokeWidth={2} name="وقت الاستجابة (ساعة)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'reports' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow text-right">
              <h3 className="text-lg font-semibold text-[#006838] mb-2">التقرير الشهري</h3>
              <p className="text-sm text-gray-600">تقرير تفصيلي عن أداء الخدمات خلال الشهر</p>
            </button>
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow text-right">
              <h3 className="text-lg font-semibold text-[#006838] mb-2">تقرير الأداء السنوي</h3>
              <p className="text-sm text-gray-600">تحليل شامل للأداء خلال العام الدراسي</p>
            </button>
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow text-right">
              <h3 className="text-lg font-semibold text-[#006838] mb-2">تقرير رضا المستفيدين</h3>
              <p className="text-sm text-gray-600">تحليل استبيانات وآراء المستفيدين</p>
            </button>
            <button className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow text-right">
              <h3 className="text-lg font-semibold text-[#006838] mb-2">تقرير الإحصائيات</h3>
              <p className="text-sm text-gray-600">إحصائيات تفصيلية عن استخدام الخدمات</p>
            </button>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      {/* Banner with Logos */}
      <div className="relative h-[400px]">
        <img 
          src="https://raw.githubusercontent.com/Atheermohamed/ut/main/Banar.png"
          alt="مبنى جامعة تبوك"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50">
          <div className="container mx-auto h-full flex flex-col">
            {/* Logos */}
            <div className="flex items-center justify-between px-6 py-4">
              <div className="flex items-center gap-4">
                <img 
                  src="https://raw.githubusercontent.com/Atheermohamed/ut/main/Untitled-8-01.png"
                  alt="شعار جامعة تبوك"
                  className="h-16 w-auto"
                />
                <div className="border-r border-[#D4AF37] h-12 mx-4"></div>
                <img 
                  src="https://raw.githubusercontent.com/Atheermohamed/ut/main/Untitled-8-02.png"
                  alt="شعار عمادة التعليم الإلكتروني"
                  className="h-16 w-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6 overflow-auto">
        {/* Units Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          {units.map((unit) => (
            <button
              key={unit.id}
              onClick={() => setSelectedUnit(unit)}
              className={`
                flex flex-col items-center justify-center p-6 rounded-xl shadow-lg
                transition-all duration-300 transform hover:scale-105
                ${selectedUnit?.id === unit.id
                  ? 'bg-[#D4AF37] text-white'
                  : 'bg-white hover:bg-[#006838] text-[#006838] hover:text-white'
                }
              `}
            >
              <div className="text-3xl mb-4">
                {unit.id === 1 && "🔄"}
                {unit.id === 2 && "📊"}
                {unit.id === 3 && "👥"}
                {unit.id === 4 && "❓"}
              </div>
              <span className="text-center font-semibold">{unit.name}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        {selectedUnit && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold text-[#006838] mb-6">{selectedUnit.name}</h2>
            {(selectedUnit.id === 1 || selectedUnit.id === 2) && renderEntityContent(selectedUnit.id)}
          </div>
        )}
      </div>
    </div>
  );
}